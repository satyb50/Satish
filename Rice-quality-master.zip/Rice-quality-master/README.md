# Rice-quality
This project detects the quality of the rice grains.
